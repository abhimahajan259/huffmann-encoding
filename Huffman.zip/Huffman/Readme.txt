The matlab files are Huffman code programs for Text compression and decompression.

I .m files
  ********

1. fhstart.m (compression main program)
2. fhtree.m
3. fhcode.m
4. b2d.m
5. fhdecode2.m (decompression main program).

Test file directory

II contains test files taken from Calgary/Canterbury.
   **************************************************

II. pdf file contains notes on static huffman coding

